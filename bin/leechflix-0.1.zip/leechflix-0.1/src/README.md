# leechflix
Popcorn-Time like movie streamer for www.torrentleech.org

Build with NodeJS for Node-webkit; scraping with cheerio; OMDb API for movie info and images; peerflix for torrent streaming.

@Todo

-don't log in for every request

-add support for tv shows

-add search

-local database or cache

-browse next (/page/2 ..)

-browse popular

-add backdrops

-use native peerflix streaming

-serch for all releases when viewing movie details
